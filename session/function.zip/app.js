require("./db/mongoose");
const  User = require("./modules/SessionData");
exports.handler = (event, context, callback) => {
    context.callbackWaitsForEmptyEventLoop = false
    const newUsers = JSON.parse(event.body);
    const users = new User(newUsers); 
        users.save().then((value) => {
            let myResponse = {
                'statusCode': 200,
                'body': JSON.stringify({
                   users
            })};
            callback(null, myResponse)
          
        }).catch((err) => {
            
            callback(Error(err), null)
          
        });
}

exports.auth = async(event) =>{
    try{
       const token = event.header("Authorization").replace('Bearer', '');
        const decoded = jwt.Verify(token, 'lamodaesteneruntokenentusession');
        const user = await User.findOne({_id:decoded._id, 'tokens.token':token});
        if(!user){
            throw new Error()
        }
        
        res = {
            'statusCode': 200,
            'body': JSON.stringify(user),
            headers: {}
        }
        next()
    } catch(e){
        res = {
            'statusCode' : 501,
            'body': JSON.stringify("ERROR",e)
        }
    }
    return res;
}



exports.login = async (event, context) => {

     try {
        const loginParams = JSON.parse(event.body);
        const loggedUser = await customLogin(loginParams.user, loginParams.password);
        return convertToResponse(loggedUser);

        }catch(err){
            return convertToError(err);
    }
    return res
}

const customLogin = (user, password)=>{

    return  new Promise((resolve, reject) => {
        User.findByCredentials(user, password).then((foundUser) =>{

            const rol = foundUser.rol
            const userName = foundUser.user
            foundUser.generateAuthToken().then((token) => {
                resolve({rol, userName, token:{token}});
            }).catch((err) => {
                reject(err);
            });
        }).catch((err) => {
            reject(err);
        });
    });
}
const convertToResponse=(value)=>{
    return {
            'statusCode': 200,
            'body': JSON.stringify(value),
            headers: {}
        }
}
const convertToError = (err)=>{
    return {
            'statusCode': 500,
            'body': JSON.stringify(value),
            headers: {}
        }

}
